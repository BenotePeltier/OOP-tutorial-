Write-Host "Calling clean to make sure the test is done from a clean slate"
make clean *>$null
Write-Host "Compiling the submission"
make
if($?)
{
    Write-Host "Compilation succeeded"
    Write-Host "Running test"
    Write-Host ""
    .\bin\Testing.exe
    if($LastExitCode -ne 0)
    {
        Write-Host ""
        Write-Host "One or more errors occured during testing"
        Write-Host "The script must pass for your code to be assessed"
    }
    else
    {
        Write-Host "Your code is ready to be turned in"
    }
}
else
{
    Write-Host "A compilation error occured"
    Write-Host "Testing cannot be conducted until all errors are fixed"
}