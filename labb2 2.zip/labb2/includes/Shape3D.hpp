#pragma once
#include<string.h>
#include "Shape.hpp"

#include <iostream>
#include <string>
using namespace std;
class Shape3D : public Shape {
public:
virtual double Area() const = 0;
virtual double Volume() const = 0;
virtual string ToString()const;

};

