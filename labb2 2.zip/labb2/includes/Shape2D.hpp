#pragma once
#include "Shape.hpp"

#include <string>

using namespace std;
const double pi = 3.14159265359;

class Shape2D : public Shape {
public:
virtual double Area() const = 0;
virtual string ToString()const;

};



