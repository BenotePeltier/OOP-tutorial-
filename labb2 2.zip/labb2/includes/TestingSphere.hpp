#ifndef TEST_SPHERE_HPP
#define TEST_SPHERE_HPP

/*******************************************************************
*						Here be Dragons
********************************************************************/

#include "TestingBase.hpp"
#include <cstdint>
#include <iostream>

#if __has_include("Sphere.hpp")
class Shape3D;
#include "Sphere.hpp"
#include <initializer_list>
#include <vector>
#include <algorithm>
#include <random>
#include <iomanip>
#include <chrono>
#include <limits>
namespace UnitTests::TestSphere
{

GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(Area)
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(Volume)
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(ToString)

static constexpr bool is_abstract = std::is_abstract<Sphere>::value;
static constexpr bool is_default_constructible = std::is_default_constructible<Sphere>::value;
static constexpr bool has_constructor = std::is_constructible<Sphere, double>::value;
static constexpr bool is_derived_from_Shape3D = std::is_base_of<Shape3D, Sphere>::value;

static constexpr bool has_Area_function = has_const_Area<Sphere, double>::value;
static constexpr bool has_Volume_function = has_const_Volume<Sphere, double>::value;
static constexpr bool has_ToString_function = has_const_ToString<Sphere, std::string>::value;

template <typename T = Sphere>
bool SphereUnitTest()
{
    bool passed = true;
    std::uint16_t indentation_level = 0;
    std::string message;
    std::cout << '\n'
              << std::string(indentation_level++, '\t') << "Starting test on class Sphere." << std::endl;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Sphere is derived from class Shape3D." << std::endl;
    if constexpr (!is_derived_from_Shape3D)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is not derived from the class Shape3D. This is a requirement for the class." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is correctly derived from class Shape3D." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Sphere is abstract." << std::endl;
    if constexpr (!is_abstract)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is not abstract." << std::endl;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is abstract. Sphere must not be abstract." << std::endl;
        passed = false;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Sphere is default constructible." << std::endl;
    if constexpr (!is_default_constructible)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is not default constructible. This is a must for the Sphere-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is default constructible." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Sphere is constructible with constructor Sphere(double)." << std::endl;
    if constexpr (!has_constructor)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is not constructible with constructor Sphere(double). This is a must for the Sphere-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Sphere is constructible with constructor Sphere(double)." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for memberfunction Sphere::Area()." << std::endl;
    if constexpr (!has_Area_function)
    {
        std::cout << std::string(indentation_level, '\t') << "Function Sphere::Area() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Sphere::Area() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level++, '\t') << "Controlling output from function Sphere::Area()." << std::endl;
        if constexpr (!is_default_constructible)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Sphere::Area() with default constructed object." << std::endl;
            passed = false;
        }
        else
        {
            T Sphere;
            double area = Sphere.Area();
            if (std::abs(area - 1256.64) < 0.01)
            {
                std::cout << std::string(indentation_level, '\t') << "Function Sphere::Area() returned expected value on a default constructed object." << std::endl;
            }
            else
            {
                std::cout << std::string(indentation_level, '\t') << "Function Sphere::Area() did not return expected value on a default constructed object." << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Expected: " << 1256.64 << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                passed = false;
            }
        }
        if constexpr (!has_constructor)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Sphere::Area() with object constructed with Sphere(double)." << std::endl;
            passed = false;
        }
        else
        {
            std::vector<double> radiuses = {
                1.0,
                2.0,
                3.0,
                4.0,
                5.0,
                6.0,
                7.0,
                8.0,
                9.0,
                100.0,
                0.1,
            };
            std::vector<double> expected_results = {
                12.5664,
                50.2655,
                113.097,
                201.062,
                314.159,
                452.389,
                615.752,
                804.248,
                1017.88,
                125663.7,
                0.125664
            };

            auto result = expected_results.begin();

            for (auto &&radius : radiuses)
            {
                T sphere(radius);
                double area = sphere.Area();
                if (std::abs(area - *result) < 0.01)
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Sphere::Area() returned expected value on a constructed object with radius " << radius << '.' << std::endl;
                }
                else
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Sphere::Area() did not return expected value on a constructed object with radius " << radius << '.' << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Expected: " << *result << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                    passed = false;
                }
                ++result;
            }
        }
        --indentation_level;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for memberfunction Sphere::Volume()." << std::endl;
    if constexpr (!has_Volume_function)
    {
        std::cout << std::string(indentation_level, '\t') << "Function Sphere::Volume() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Sphere::Volume() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level++, '\t') << "Controlling output from function Sphere::Volume()." << std::endl;
        if constexpr (!is_default_constructible)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Sphere::Volume() with default constructed object." << std::endl;
            passed = false;
        }
        else
        {
            T Sphere;
            double area = Sphere.Volume();
            if (std::abs(area - 4188.79) < 0.01)
            {
                std::cout << std::string(indentation_level, '\t') << "Function Sphere::Volume() returned expected value on a default constructed object." << std::endl;
            }
            else
            {
                std::cout << std::string(indentation_level, '\t') << "Function Sphere::Volume() did not return expected value on a default constructed object." << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Expected: " << 4188.79 << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                passed = false;
            }
        }
        if constexpr (!has_constructor)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Sphere::Area() with object constructed with Sphere(double)." << std::endl;
            passed = false;
        }
        else
        {
            std::vector<double> radiuses = {
                1.0,
                2.0,
                3.0,
                4.0,
                5.0,
                6.0,
                7.0,
                8.0,
                9.0,
                100.0,
                0.1,
            };
            std::vector<double> expected_results = {
                4.18879,
                33.5103,
                113.097,
                268.083,
                523.599,
                904.779,
                1436.76,
                2144.66,
                3053.63,
                4188790.20,
                0.00418879
            };

            auto result = expected_results.begin();

            for (auto &&radius : radiuses)
            {
                T Sphere(radius);
                double area = Sphere.Volume();
                if (std::abs(area - *result) < 0.01)
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Sphere::Volume() returned expected value on a constructed object with radius " << radius << '.' << std::endl;
                }
                else
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Sphere::Volume() did not return expected value on a constructed object with radius " << radius << '.' << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Expected: " << *result << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                    passed = false;
                }
                ++result;
            }
        }
        --indentation_level;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for function Sphere::ToString()." << std::endl;
    if constexpr (!has_ToString_function)
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Sphere::ToString() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Sphere::ToString() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level--, '\t') << "Note: This function will be manually checked. It is unfortunately hard to make a computer see if something is easily readable" << std::endl;
    }
    --indentation_level;

    indentation_level--;
    std::cout << std::string(indentation_level, '\t') << "Testing on class Sphere finished." << std::endl;
    return passed;
}
} // namespace UnitTests::TestSphere

#else
namespace UnitTests::TestSphere
{
bool SphereUnitTest()
{
    std::cout << "File Sphere.hpp non-existent." << std::endl;
    return false;
}
} // namespace UnitTests::TestSphere
#endif // __has_include
#endif // ifndef