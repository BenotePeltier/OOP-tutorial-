#include "Shape2D.hpp"
#include<string.h>

#include <iostream>
#include <string>
using namespace std;

class Rectangle : public Shape2D {
    double height;
    double Width;
public:
Rectangle();
Rectangle(double height, double width);

double Area() const;
string ToString()const;



};



