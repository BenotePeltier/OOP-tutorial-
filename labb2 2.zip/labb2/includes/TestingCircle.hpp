#ifndef TEST_CIRCLE_HPP
#define TEST_CIRCLE_HPP

/*******************************************************************
*						Here be Dragons
********************************************************************/

#include "TestingBase.hpp"
#include <cstdint>
#include <iostream>

#if __has_include("Circle.hpp")
class Shape2D;
#include "Circle.hpp"
#include <initializer_list>
#include <vector>
#include <algorithm>
#include <random>
#include <iomanip>
#include <chrono>
#include <limits>
namespace UnitTests::TestCircle
{
    
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(Area)
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(ToString)


static constexpr bool is_abstract = std::is_abstract<Circle>::value;
static constexpr bool is_default_constructible = std::is_default_constructible<Circle>::value;
static constexpr bool has_constructor = std::is_constructible<Circle, double>::value;
static constexpr bool is_derived_from_shape2D = std::is_base_of<Shape2D, Circle>::value;

static constexpr bool has_Area_function = has_const_Area<Circle, double>::value;
static constexpr bool has_ToString_function = has_const_ToString<Circle, std::string>::value;

template <typename T = Circle>
bool CircleUnitTest()
{
    bool passed = true;
    std::uint16_t indentation_level = 0;
    std::string message;
    std::cout << '\n'
              << std::string(indentation_level++, '\t') << "Starting test on class Circle." << std::endl;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Circle is derived from class Shape2D." << std::endl;
    if constexpr (!is_derived_from_shape2D)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is not derived from the class Shape2D. This is a requirement for the class." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is correctly derived from class Shape2D." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Circle is abstract." << std::endl;
    if constexpr (!is_abstract)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is not abstract." << std::endl;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is abstract. Circle must not be abstract." << std::endl;
        passed = false;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Circle is default constructible." << std::endl;
    if constexpr(!is_default_constructible)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is not default constructible. This is a must for the Circle-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is default constructible." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Circle is constructible with constructor Circle(double)." << std::endl;
    if constexpr(!has_constructor)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is not constructible with constructor Circle(double). This is a must for the Circle-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Circle is constructible with constructor Circle(double)." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for memberfunction Circle::Area()." << std::endl;
    if constexpr (!has_Area_function)
    {
        std::cout << std::string(indentation_level, '\t') << "Function Circle::Area() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Circle::Area() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level++, '\t') << "Controlling output from function Circle::Area()." << std::endl;
        if constexpr(!is_default_constructible)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Circle::Area() with default constructed object." << std::endl;
            passed = false;
        }
        else
        {
            T circle;
            double area = circle.Area();
            if(std::abs(area - 314.159) < 0.001)
            {
                std::cout << std::string(indentation_level, '\t')  << "Function Circle::Area() returned expected value on a default constructed object." << std::endl;
            }
            else
            {
                std::cout << std::string(indentation_level, '\t') << "Function Circle::Area() did not return expected value on a default constructed object." << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Expected: " << 314.159 << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                passed = false;
            }
        }
        if constexpr(!has_constructor)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Circle::Area() with object constructed with Circle(double)." << std::endl;
            passed = false;
        }
        else
        {
            std::vector<double> radiuses = {1, 2, 3, 4, 5, 6, 7, 8, 9, 100, 1000};
            std::vector<double> expected_results = {
                3.14159,
                12.5664,
                28.2743,
                50.2655,
                78.5398,
                113.097,
                153.938,
                201.062,
                254.469,
                31415.9,
                3141592.7
            };

            auto result = expected_results.begin();

            for(auto &&radius : radiuses)
            {
                T circle(radius);
                double area = circle.Area();
                if(std::abs(area - *result) < 0.1)
                {
                    std::cout << std::string(indentation_level, '\t')  << "Function Circle::Area() returned expected value on a constructed object with radius " << radius << '.' << std::endl;
                }
                else
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Circle::Area() did not return expected value on a constructed object with radius " << radius << '.' << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Expected: " << *result << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                    passed = false;
                }
                ++result;
            }
        }
        --indentation_level;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for function Circle::ToString()." << std::endl;
    if constexpr (!has_ToString_function)
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Circle::ToString() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Circle::ToString() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level--, '\t') << "Note: This function will be manually checked. It is unfortunately hard to make a computer see if something is easily readable" << std::endl;
    }
    --indentation_level;

    indentation_level--;
    std::cout << std::string(indentation_level, '\t') << "Testing on class Circle finished." << std::endl;
    return passed;
}
} // namespace UnitTests::TestCircle

#else
namespace UnitTests::TestCircle
{
bool CircleUnitTest()
{
    std::cout << "File Circle.hpp non-existent." << std::endl;
    return false;
}
} // namespace UnitTests::TestCircle
#endif // __has_include
#endif // ifndef