#ifndef TEST_RECTANGLE_HPP
#define TEST_RECTANGLE_HPP

/*******************************************************************
*						Here be Dragons
********************************************************************/

#include "TestingBase.hpp"
#include <cstdint>
#include <iostream>

#if __has_include("Rectangle.hpp")
class Shape2D;
#include "Rectangle.hpp"
#include <initializer_list>
#include <vector>
#include <algorithm>
#include <random>
#include <iomanip>
#include <chrono>
#include <limits>
#include <utility>
namespace UnitTests::TestRectangle
{
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(Area)
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(ToString)

static constexpr bool is_abstract = std::is_abstract<Rectangle>::value;
static constexpr bool is_default_constructible = std::is_default_constructible<Rectangle>::value;
static constexpr bool has_constructor = std::is_constructible<Rectangle, double, double>::value;
static constexpr bool is_derived_from_shape2D = std::is_base_of<Shape2D, Rectangle>::value;

static constexpr bool has_Area_function = has_const_Area<Rectangle, double>::value;
static constexpr bool has_ToString_function = has_const_ToString<Rectangle, std::string>::value;

template <typename T = Rectangle>
bool RectangleUnitTest()
{
    bool passed = true;
    std::uint16_t indentation_level = 0;
    std::string message;
    std::cout << '\n'
              << std::string(indentation_level++, '\t') << "Starting test on class Rectangle." << std::endl;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Rectangle is derived from class Shape2D." << std::endl;
    if constexpr (!is_derived_from_shape2D)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is not derived from the class Shape2D. This is a requirement for the class." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is correctly derived from class Shape2D." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Rectangle is abstract." << std::endl;
    if constexpr (!is_abstract)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is not abstract." << std::endl;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is abstract. Rectangle must not be abstract." << std::endl;
        passed = false;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Rectangle is default constructible." << std::endl;
    if constexpr (!is_default_constructible)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is not default constructible. This is a must for the Rectangle-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is default constructible." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Rectangle is constructible with constructor Rectangle(double, double)." << std::endl;
    if constexpr (!has_constructor)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is not constructible with constructor Rectangle(double, double). This is a must for the Rectangle-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Rectangle is constructible with constructor Rectangle(double, double)." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for memberfunction Rectangle::Area()." << std::endl;
    if constexpr (!has_Area_function)
    {
        std::cout << std::string(indentation_level, '\t') << "Function Rectangle::Area() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Rectangle::Area() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level++, '\t') << "Controlling output from function Rectangle::Area()." << std::endl;
        if constexpr (!is_default_constructible)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Rectangle::Area() with default constructed object." << std::endl;
            passed = false;
        }
        else
        {
            T Rectangle;
            double area = Rectangle.Area();
            if (std::abs(area - 100.0) < 0.001)
            {
                std::cout << std::string(indentation_level, '\t') << "Function Rectangle::Area() returned expected value on a default constructed object." << std::endl;
            }
            else
            {
                std::cout << std::string(indentation_level, '\t') << "Function Rectangle::Area() did not return expected value on a default constructed object." << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Expected: " << 100.0 << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                passed = false;
            }
        }
        if constexpr (!has_constructor)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Rectangle::Area() with object constructed with Rectangle(double)." << std::endl;
            passed = false;
        }
        else
        {
            std::vector<std::pair<double, double>> lengths_and_widths = {
                {1.0, 1.0},
                {2.0, 2.0},
                {3.0, 3.0},
                {4.0, 4.0},
                {5.0, 5.0},
                {6.0, 6.0},
                {7.0, 7.0},
                {8.0, 8.0},
                {9.0, 9.0},
                {100.0, 100.0},
                {0.1, 0.1},
                {23.0, 25.0},
                {87.0, 18.0}};
            std::vector<double> expected_results = {
                1.0,
                4.0,
                9.0,
                16.0,
                25.0,
                36.0,
                49.0,
                64.0,
                81.0,
                10'000.0,
                0.01,
                575.0,
                1566.0};

            auto result = expected_results.begin();

            for (auto &&length_and_width : lengths_and_widths)
            {
                T rectangle(length_and_width.first, length_and_width.second);
                double area = rectangle.Area();
                if (std::abs(area - *result) < 0.1)
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Rectangle::Area() returned expected value on a constructed object with length " << length_and_width.first << " and width " << length_and_width.first << '.' << std::endl;
                }
                else
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Rectangle::Area() did not return expected value on a constructed object with length " << length_and_width.first << " and width " << length_and_width.first << '.' << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Expected: " << *result << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                    passed = false;
                }
                ++result;
            }
        }
        --indentation_level;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for function Rectangle::ToString()." << std::endl;
    if constexpr (!has_ToString_function)
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Rectangle::ToString() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Rectangle::ToString() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level--, '\t') << "Note: This function will be manually checked. It is unfortunately hard to make a computer see if something is easily readable" << std::endl;
    }
    --indentation_level;

    indentation_level--;
    std::cout << std::string(indentation_level, '\t') << "Testing on class Rectangle finished." << std::endl;
    return passed;
}
} // namespace UnitTests::TestRectangle

#else
namespace UnitTests::TestRectangle
{
bool RectangleUnitTest()
{
    std::cout << "File Rectangle.hpp non-existent." << std::endl;
    return false;
}
} // namespace UnitTests::TestRectangle
#endif // __has_include
#endif // ifndef