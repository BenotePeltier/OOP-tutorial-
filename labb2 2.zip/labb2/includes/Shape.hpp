#pragma once
#include <string>

using namespace std;

class Shape {
public:
    Shape();
    virtual string ToString()const;
    virtual double Area()const=0;


};
