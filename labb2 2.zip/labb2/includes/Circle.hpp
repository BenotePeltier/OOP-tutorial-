#include "Shape2D.hpp"
#include<string.h>

#include <iostream>
#include <string>
using namespace std;


class Circle : public Shape2D {
    double radius;
public:
Circle();
Circle(double radius);

double Area() const;
string ToString()const;




};



