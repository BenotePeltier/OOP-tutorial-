#ifndef TEST_SHAPE2D_HPP
#define TEST_SHAPE2D_HPP

/*******************************************************************
*						Here be Dragons
********************************************************************/

#include "TestingBase.hpp"
#include <cstdint>
#include <iostream>

#if __has_include("Shape2D.hpp")
class Shape;
#include "Shape2D.hpp"
#include <initializer_list>
#include <vector>
#include <algorithm>
#include <random>
#include <iomanip>
#include <chrono>
#include <limits>
#include <string>
namespace UnitTests::TestShape2D
{

GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(Area)
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(ToString)

static constexpr bool is_abstract = std::is_abstract<Shape2D>::value;
static constexpr bool is_default_constructible = std::is_default_constructible<Shape2D>::value;
static constexpr bool is_derived_from_shape = std::is_base_of<Shape, Shape2D>::value;

static constexpr bool has_Area_function = has_const_Area<Shape2D, double>::value || has_const_Area<Shape, double>::value;
static constexpr bool has_ToString_function = has_const_ToString<Shape2D, std::string>::value || has_const_ToString<Shape, std::string>::value;

template <typename T = Shape2D>
bool Shape2DUnitTest()
{
    bool passed = true;
    std::uint16_t indentation_level = 0;
    std::string message;
    std::cout << '\n'
              << std::string(indentation_level++, '\t') << "Starting test on class Shape2D." << std::endl;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Shape2D is derived from class Shape." << std::endl;
    if constexpr (!is_derived_from_shape)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Shape2D is not derived from the class Shape. This is a requirement for the class." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Shape2D is correctly derived from class Shape." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Shape2D is abstract." << std::endl;
    if constexpr (!is_abstract)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Shape2D is not abstract. This is a requirement for the class." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Shape2D is abstract." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for memberfunction Shape2D::Area()." << std::endl;
    if constexpr (!has_Area_function)
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Shape2D::Area() not found with expected signature." << std::endl;
        std::cout << std::string(indentation_level--, '\t') << "Expected signature double Area() const to be part of Shape2D, due to this being a function in all subclasses." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Shape2D::Area() found with expected signature." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for function Shape2D::ToString()." << std::endl;
    if constexpr (!has_ToString_function)
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Shape2D::ToString() not found with expected signature." << std::endl;
        std::cout << std::string(indentation_level--, '\t') << "Expected signature std::string ToString() const to be part of Shape2D, due to this being a function in all subclasses." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Shape2D::ToString() found with expected signature." << std::endl;
    }
    --indentation_level;

    indentation_level--;
    std::cout << std::string(indentation_level, '\t') << "Testing on class Shape2D finished." << std::endl;
    return passed;
}
} // namespace UnitTests::TestShape2D

#else
namespace UnitTests::TestShape2D
{
bool Shape2DUnitTest()
{
    std::cout << "File Shape2D.hpp non-existent." << std::endl;
    return false;
}
} // namespace UnitTests::TestShape2D
#endif // __has_include
#endif // ifndef