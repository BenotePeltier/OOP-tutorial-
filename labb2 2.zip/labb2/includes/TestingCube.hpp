#ifndef TEST_CUBE_HPP
#define TEST_CUBE_HPP

/*******************************************************************
*						Here be Dragons
********************************************************************/

#include "TestingBase.hpp"
#include <cstdint>
#include <iostream>

#if __has_include("Cube.hpp")
class Shape3D;
#include "Cube.hpp"
#include <initializer_list>
#include <vector>
#include <algorithm>
#include <random>
#include <iomanip>
#include <chrono>
#include <limits>
namespace UnitTests::TestCube
{

GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(Area)
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(Volume)
GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(ToString)

static constexpr bool is_abstract = std::is_abstract<Cube>::value;
static constexpr bool is_default_constructible = std::is_default_constructible<Cube>::value;
static constexpr bool has_constructor = std::is_constructible<Cube, double>::value;
static constexpr bool is_derived_from_Shape3D = std::is_base_of<Shape3D, Cube>::value;

static constexpr bool has_Area_function = has_const_Area<Cube, double>::value;
static constexpr bool has_Volume_function = has_const_Volume<Cube, double>::value;
static constexpr bool has_ToString_function = has_const_ToString<Cube, std::string>::value;

template <typename T = Cube>
bool CubeUnitTest()
{
    bool passed = true;
    std::uint16_t indentation_level = 0;
    std::string message;
    std::cout << '\n'
              << std::string(indentation_level++, '\t') << "Starting test on class Cube." << std::endl;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Cube is derived from class Shape3D." << std::endl;
    if constexpr (!is_derived_from_Shape3D)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is not derived from the class Shape3D. This is a requirement for the class." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is correctly derived from class Shape3D." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Cube is abstract." << std::endl;
    if constexpr (!is_abstract)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is not abstract." << std::endl;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is abstract. Cube must not be abstract." << std::endl;
        passed = false;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Cube is default constructible." << std::endl;
    if constexpr (!is_default_constructible)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is not default constructible. This is a must for the Cube-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is default constructible." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Checking if Cube is constructible with constructor Cube(double)." << std::endl;
    if constexpr (!has_constructor)
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is not constructible with constructor Cube(double). This is a must for the Cube-class" << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Class Cube is constructible with constructor Cube(double)." << std::endl;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for memberfunction Cube::Area()." << std::endl;
    if constexpr (!has_Area_function)
    {
        std::cout << std::string(indentation_level, '\t') << "Function Cube::Area() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Cube::Area() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level++, '\t') << "Controlling output from function Cube::Area()." << std::endl;
        if constexpr (!is_default_constructible)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Cube::Area() with default constructed object." << std::endl;
            passed = false;
        }
        else
        {
            T cube;
            double area = cube.Area();
            if (std::abs(area - 600.0) < 0.001)
            {
                std::cout << std::string(indentation_level, '\t') << "Function Cube::Area() returned expected value on a default constructed object." << std::endl;
            }
            else
            {
                std::cout << std::string(indentation_level, '\t') << "Function Cube::Area() did not return expected value on a default constructed object." << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Expected: " << 600.0 << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                passed = false;
            }
        }
        if constexpr (!has_constructor)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Cube::Area() with object constructed with Cube(double)." << std::endl;
            passed = false;
        }
        else
        {
            std::vector<double> side_lengths = {
                1.0,
                2.0,
                3.0,
                4.0,
                5.0,
                6.0,
                7.0,
                8.0,
                9.0,
                100.0,
                0.1,
            };
            std::vector<double> expected_results = {
                6.0,
                24.0,
                54.0,
                96.0,
                150.0,
                216.0,
                294.0,
                384.0,
                486.0,
                60'000.0,
                0.06
            };

            auto result = expected_results.begin();

            for (auto &&side_length : side_lengths)
            {
                T cube(side_length);
                double area = cube.Area();
                if (std::abs(area - *result) < 0.1)
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Cube::Area() returned expected value on a constructed object with side length " << side_length << '.' << std::endl;
                }
                else
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Cube::Area() did not return expected value on a constructed object with side length " << side_length << '.' << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Expected: " << *result << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                    passed = false;
                }
                ++result;
            }
        }
        --indentation_level;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for memberfunction Cube::Volume()." << std::endl;
    if constexpr (!has_Volume_function)
    {
        std::cout << std::string(indentation_level, '\t') << "Function Cube::Volume() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level, '\t') << "Function Cube::Volume() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level++, '\t') << "Controlling output from function Cube::Volume()." << std::endl;
        if constexpr (!is_default_constructible)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Cube::Volume() with default constructed object." << std::endl;
            passed = false;
        }
        else
        {
            T cube;
            double area = cube.Volume();
            if (std::abs(area - 1'000.0) < 0.001)
            {
                std::cout << std::string(indentation_level, '\t') << "Function Cube::Volume() returned expected value on a default constructed object." << std::endl;
            }
            else
            {
                std::cout << std::string(indentation_level, '\t') << "Function Cube::Volume() did not return expected value on a default constructed object." << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Expected: " << 1'000.0 << std::endl;
                std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                passed = false;
            }
        }
        if constexpr (!has_constructor)
        {
            std::cout << std::string(indentation_level, '\t') << "Cannot conduct control of Cube::Area() with object constructed with Cube(double)." << std::endl;
            passed = false;
        }
        else
        {
            std::vector<double> side_lengths = {
                1.0,
                2.0,
                3.0,
                4.0,
                5.0,
                6.0,
                7.0,
                8.0,
                9.0,
                100.0,
                0.1,
            };
            std::vector<double> expected_results = {
                1.0,
                8.0,
                27.0,
                64.0,
                125.0,
                216.0,
                343.0,
                512.0,
                729.0,
                1'000'000.0,
                0.001
            };

            auto result = expected_results.begin();

            for (auto &&side_length : side_lengths)
            {
                T cube(side_length);
                double area = cube.Volume();
                if (std::abs(area - *result) < 0.1)
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Cube::Volume() returned expected value on a constructed object with side length " << side_length << '.' << std::endl;
                }
                else
                {
                    std::cout << std::string(indentation_level, '\t') << "Function Cube::Volume() did not return expected value on a constructed object with side length " << side_length << '.' << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Expected: " << *result << std::endl;
                    std::cout << std::string(indentation_level, '\t') << "Received: " << area << std::endl;
                    passed = false;
                }
                ++result;
            }
        }
        --indentation_level;
    }
    --indentation_level;
    std::cout << std::string(indentation_level++, '\t') << "Looking for function Cube::ToString()." << std::endl;
    if constexpr (!has_ToString_function)
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Cube::ToString() not found with expected signature." << std::endl;
        passed = false;
    }
    else
    {
        std::cout << std::string(indentation_level++, '\t') << "Function Cube::ToString() found with expected signature." << std::endl;
        std::cout << std::string(indentation_level--, '\t') << "Note: This function will be manually checked. It is unfortunately hard to make a computer see if something is easily readable" << std::endl;
    }
    --indentation_level;

    indentation_level--;
    std::cout << std::string(indentation_level, '\t') << "Testing on class Cube finished." << std::endl;
    return passed;
}
} // namespace UnitTests::TestCube

#else
namespace UnitTests::TestCube
{
bool CubeUnitTest()
{
    std::cout << "File Cube.hpp non-existent." << std::endl;
    return false;
}
} // namespace UnitTests::TestCube
#endif // __has_include
#endif // ifndef