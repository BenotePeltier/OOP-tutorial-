#include "Shape3D.hpp"
#include<string.h>

#include <iostream>
#include <string>
using namespace std;

class Cube : public Shape3D {
    double sideLength;

public:
Cube();
Cube(double sideLength);


double Volume() const;
double Area() const;
string ToString()const;


};



