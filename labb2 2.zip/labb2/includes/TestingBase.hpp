#ifndef TESTING_BASE_HPP
#define TESTING_BASE_HPP
/*******************************************************************
*						Here be Dragons
********************************************************************/

#include <type_traits>
#include <functional>
#include <cctype>
#include <cstdint>
#include <functional>
#include <iostream>
#include <string>

#define GENERATE_HAS_MEMBER_FUNCTION(function_name, member_function)                  \
    template <typename T, typename RESULT, typename... ARGS>                          \
    class has_##function_name                                                         \
    {                                                                                 \
        typedef std::true_type yes;                                                   \
        typedef std::false_type no;                                                   \
        template <typename U, RESULT (U::*)(ARGS...)>                                 \
        struct Check;                                                                 \
        template <typename U>                                                         \
        static yes func(Check<U, &U::member_function> *);                             \
        template <typename>                                                           \
        static no func(...);                                                          \
                                                                                      \
    public:                                                                           \
        typedef has_##function_name type;                                             \
        static constexpr bool value = std::is_same<decltype(func<T>(0)), yes>::value; \
    };

#define GENERATE_HAS_CONST_MEMBER_FUNCTION(function_name, member_function)            \
    template <typename T, typename RESULT, typename... ARGS>                          \
    class has_const_##function_name                                                   \
    {                                                                                 \
        typedef std::true_type yes;                                                   \
        typedef std::false_type no;                                                   \
        template <typename U, RESULT (U::*)(ARGS...) const>                           \
        struct Check;                                                                 \
        template <typename U>                                                         \
        static yes func(Check<U, &U::member_function> *);                             \
        template <typename>                                                           \
        static no func(...);                                                          \
                                                                                      \
    public:                                                                           \
        typedef has_const_##function_name type;                                       \
        static constexpr bool value = std::is_same<decltype(func<T>(0)), yes>::value; \
    };



#define GENERATE_SAME_NAME_HAS_MEMBER_FUNCTION(name) GENERATE_HAS_MEMBER_FUNCTION(name, name)
#define GENERATE_SAME_NAME_HAS_CONST_MEMBER_FUNCTION(name) GENERATE_HAS_CONST_MEMBER_FUNCTION(name, name)

/*
* 
*   Usage:
*       GENERATE_HAS_MEMBER_FUNCTION(function_name, member_function) creates a template-based struct.
*       This struct can then be used as: has_function_name<ClassToCheck, ExpectedReturnType, ArgType1, ArgType2,...>::value.       
*       If this value is true, then the ClassToCheck has a member method named function_name that matches the signature given.
*       The args can be empty.
*       To check for const functions, GENERATE_HAS_CONST_MEMBER_FUNCTION must be used.
*       For same function_name as member_function, use GENERATE_SAME_NAME_HAS...
* 
*   Important!
*       This code will not be able to check for constructor, use is_constructible for this!
* 
* 
* 
* 
*/

bool TryCatchHelper(std::function<void()> function, bool pass_on_catch, std::size_t &text_indentation_level, std::string current_test, std::string on_fail_message)
{
    try
    {
        std::cout << std::string(text_indentation_level, '\t') + "Calling " + current_test << std::endl;
        function();
        if (!pass_on_catch)
        {
            std::cout << std::string(text_indentation_level, '\t') + "Calling " + current_test + " passed." << std::endl;
            return true;
        }
        else
        {
            ++text_indentation_level;
            std::cout << std::string(text_indentation_level, '\t') + "Calling " + current_test + " failed." << std::endl;
            std::cout << std::string(text_indentation_level, '\t') + on_fail_message << std::endl;
            --text_indentation_level;
            return false;
        }
    }
    catch (const std::exception &e)
    {
        if (!pass_on_catch)
        {
            ++text_indentation_level;
            std::cout << std::string(text_indentation_level, '\t') + "Calling " + current_test + " caused exception with message \"" << e.what() << "\" to be thrown.\n";
            std::cout << std::string(text_indentation_level, '\t') + on_fail_message << std::endl;
            --text_indentation_level;
            return false;
        }
        else
        {
            std::cout << std::string(text_indentation_level, '\t') + "Calling " + current_test + " caused exception with message \"" << e.what() << "\" to be correctly thrown.\n";
            return true;
        }
    }
    catch (...)
    {
        if (!pass_on_catch)
        {
            ++text_indentation_level;
            std::cout << std::string(text_indentation_level, '\t') + "Calling " + current_test + " caused exception to be thrown.\n";
            std::cout << std::string(text_indentation_level, '\t') + on_fail_message << std::endl;
            --text_indentation_level;
            return false;
        }
        else
        {
            std::cout << std::string(text_indentation_level, '\t') + "Calling " + current_test + " caused exception to be correctly thrown.\n";
            return true;
        }
    }
}

template <typename T>
std::string VectorToString(const std::vector<T> &to_transform)
{
    std::string content = "{";
    for (auto &&nodeElement : to_transform)
    {
        content += std::to_string(nodeElement) + ", ";
    }

    if (to_transform.size())
    {
        content.pop_back();
        content.pop_back();
    }
    content += "}";
    return content;
}

#define MARK_UNUSED(variable) (void)variable;

template <class T, class Enable = void>
struct is_defined
{
    static constexpr bool value = false;
};

template <class T>
struct is_defined<T, std::enable_if_t<(sizeof(T) > 0)>>
{
    static constexpr bool value = true;
};

#endif