#include "Rectangle.hpp"

Rectangle::Rectangle(){
    Width = 10.0;
    height = 10.0;
} 

Rectangle::Rectangle(double height, double width){
this->height = height;
this->Width = width;

}

double Rectangle::Area() const{
return (height * Width);

}

string Rectangle :: ToString()const{

string res = to_string(Area());
return res;

}





