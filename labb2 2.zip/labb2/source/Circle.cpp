#include "../includes/Circle.hpp"

Circle::Circle(){
    radius = 10.0;
} 

Circle::Circle(double radius){
this->radius = radius;

}

double Circle :: Area() const{
return (pi*radius*radius);

}
string Circle :: ToString()const{

string res = to_string(Area());
return res;



}





