#include "Cube.hpp"

Cube::Cube(){
sideLength = 10.0;
}

Cube::Cube(double sideLength){
this->sideLength = sideLength;
}

double Cube::Volume() const{
return static_cast<double>(sideLength*sideLength*sideLength);
}

double Cube:: Area() const{
return (sideLength*sideLength) * 6;
}

string Cube:: ToString()const{
string res = to_string(Area());
return res;



}


