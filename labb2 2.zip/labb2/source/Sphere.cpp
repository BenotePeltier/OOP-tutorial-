#include "Sphere.hpp"

Sphere::Sphere(){
radius = 10.0;
}

Sphere::Sphere(double radius){

this->radius = radius;

}

double Sphere:: Volume() const{
return  (4 * pi * radius * radius * radius)/3;

}
double Sphere:: Area() const{
return (pi*radius*radius) * 4;

}
string Sphere:: ToString()const{

string res = to_string(Area());
return res;

}
